ALTER TABLE "Chat" ADD COLUMN "lastContext" jsonb;
