ALTER TABLE "Document" ADD COLUMN "text" varchar DEFAULT 'text' NOT NULL;
